O que eu fiz neste projeto front-end:
1. Adicionei arquivos:
   - .env (default para desenvolvimento)
   - .env.example (com variaveis de dev/staging/prod)
   - .gitignore (adicionado/atualizado)
   - src/api/axios.ts (wrapper axios usando import.meta.env.VITE_API_URL)

2. Ajustes automáticos:
   - Atualizei scripts em package.json se estavam faltando.

3. Como testar localmente:
   - Na raiz do projeto:
     npm install
     npm run dev
   - Abra http://localhost:5173 (ou porta indicada pelo Vite).

4. Como usar a nova instância axios:
   - Em vez de importar axios diretamente, use:
       import api from "./api/axios";
     Exemplo:
       await api.post('/auth/login', { email: 'seu@email.com', password: 'senha' });

5. Integração com backend:
   - Por padrão .env aponta para http://localhost:5000
   - Para staging/prod, copie .env.example para .env e ajuste VITE_API_URL
   - No backend, habilite CORS para origem do front (ex: http://localhost:5173) com algo como:
       // express example
       import cors from 'cors';
       app.use(cors({ origin: 'http://localhost:5173', credentials: true }));

6. Se quiser, posso:
   - Substituir importações de axios existentes para usar o wrapper automaticamente (posso tentar fazer isso se quiser).
   - Receber seu back-end e configurar CORS automaticamente.

Arquivos modificados/criados: 
- .env, .env.example, .gitignore (append), src/api/axios.ts
